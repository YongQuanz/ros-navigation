#!/usr/bin/env python
import os

os.system("rosnode kill /slam_gmapping")
